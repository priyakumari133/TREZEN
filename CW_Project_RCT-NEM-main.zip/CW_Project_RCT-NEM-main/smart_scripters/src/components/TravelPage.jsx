export const TravelPage = () => {
  return (
    <div>
      
    </div>
  )
}
