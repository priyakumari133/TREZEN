import Footer from "../components/Footer"
import { Navbar } from "../components/Navbar"

export const Videos = ()=>{
    return(
        <div>
        <Navbar/>
        <h1>Videos</h1>
        <Footer/>
        </div>
    )
}