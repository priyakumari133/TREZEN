import Footer from "../components/Footer"
import { Navbar } from "../components/Navbar"

export const Advature = ()=>{
    return(
        <div>
        <Navbar/>
        <h1>Advanture</h1>
        <Footer/>
        </div>
    )
}